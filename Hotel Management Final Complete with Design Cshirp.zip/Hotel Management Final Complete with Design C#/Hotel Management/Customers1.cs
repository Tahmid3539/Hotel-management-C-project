﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hotel_Management
{
    class Customers1
    {
        public int CustomerId { get; set; }
        public string CustomerContact { get; set; }
        public string CustomerName { get; set; }

        public string CustomerRoomNo { get; set; }

        public string Payment { get; set; }
    }
}
